package de.kompf.jugda.testing.basic;

public interface Calculator {
	long nfac(int n);
}
