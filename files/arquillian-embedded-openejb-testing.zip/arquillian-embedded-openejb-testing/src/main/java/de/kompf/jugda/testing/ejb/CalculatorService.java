package de.kompf.jugda.testing.ejb;

import javax.ejb.Local;

@Local
public interface CalculatorService {
	public long binomialCoefficient(int n, int k);
}
