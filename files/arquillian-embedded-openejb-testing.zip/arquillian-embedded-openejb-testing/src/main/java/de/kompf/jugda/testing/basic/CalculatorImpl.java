package de.kompf.jugda.testing.basic;

public class CalculatorImpl implements Calculator {

	public long nfac(int n) {
		if (n == 0) {
			return 1;
		} else {
			return n * nfac(n-1);
		}
	}
}
