package de.kompf.jugda.testing.ejb;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

import de.kompf.jugda.testing.basic.CalculatorImpl;

@Stateless
public class CalculatorServiceBean implements CalculatorService {

	@Resource
	private SessionContext ctx;
	
	private CalculatorImpl impl;
	
	@PostConstruct
	void create() {
		impl = new CalculatorImpl();
	}

	public long binomialCoefficient(int n, int k) {
		if (n < 0 || k < 0) {
			ctx.setRollbackOnly();
		}
		if (ctx.getRollbackOnly()) {
			return 0;
		}

		return impl.nfac(n) / impl.nfac(n-k) / impl.nfac(k);
	}

}
