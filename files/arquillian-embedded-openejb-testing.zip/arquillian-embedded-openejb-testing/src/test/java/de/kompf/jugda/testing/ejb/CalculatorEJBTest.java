package de.kompf.jugda.testing.ejb;

import static org.junit.Assert.*;

import javax.ejb.EJB;

import org.jboss.arquillian.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.Test;
import org.junit.runner.RunWith;

import de.kompf.jugda.testing.basic.CalculatorImpl;

@RunWith(Arquillian.class)
public class CalculatorEJBTest {

	@EJB
	private CalculatorService calcService;

	@Deployment
	public static JavaArchive createTestArchive() {
		return ShrinkWrap.create(JavaArchive.class, "test.jar").addClasses(
				CalculatorImpl.class, CalculatorServiceBean.class, CalculatorService.class);
	}
	
	@Test
	public void testBinomialCoefficient() {
		assertEquals(1, calcService.binomialCoefficient(0, 0));
		assertEquals(1, calcService.binomialCoefficient(1, 1));
		assertEquals(1, calcService.binomialCoefficient(1, 0));
		assertEquals(2, calcService.binomialCoefficient(2, 1));
		assertEquals(35, calcService.binomialCoefficient(7, 3));
	}


	@Test
	public void testRollback() {
		assertEquals(0, calcService.binomialCoefficient(-1, 1));
	}
}
