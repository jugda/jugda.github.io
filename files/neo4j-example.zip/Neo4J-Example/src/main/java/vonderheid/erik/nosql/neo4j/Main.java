package vonderheid.erik.nosql.neo4j;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;
import org.neo4j.graphdb.RelationshipType;
import org.neo4j.graphdb.Transaction;
import org.neo4j.index.IndexHits;
import org.neo4j.index.IndexService;
import org.neo4j.index.lucene.LuceneFulltextQueryIndexService;
import org.neo4j.kernel.EmbeddedGraphDatabase;

public class Main {

	private static final String KEY_NAME = "name";
	private static final String KEY_FIRST_NAME = "firstName";
	private static final String KEY_TITLE = "title";

	public enum MyRelationshipTypes implements RelationshipType {
        ATTENDED("has attended to");
        
        private String message;
        
        private MyRelationshipTypes(String message) {
			this.message = message;
		}
        
        @Override
        public String toString() {
        	return message;
        }
    }
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		GraphDatabaseService jugMembers = new EmbeddedGraphDatabase("var/base");		 
		 
        Transaction tx = jugMembers.beginTx();
        try {
        	// clear db
        	for(Node node : jugMembers.getAllNodes()) {
        		for(Relationship rel : node.getRelationships()) {
        			rel.delete();
        		}
        		node.delete();
        	}
        	
        	// create indexing service
        	IndexService index = new LuceneFulltextQueryIndexService(jugMembers);
        	Node johannes = jugMembers.createNode();
        	johannes.setProperty(KEY_FIRST_NAME, "Johannes");
            johannes.setProperty(KEY_NAME, "Leebmann");
            index.index(johannes, KEY_FIRST_NAME, "Johannes");
        	
            Node erik = jugMembers.createNode();
            erik.setProperty(KEY_FIRST_NAME, "Erik");
            erik.setProperty(KEY_NAME, "Vonderheid");
            index.index(erik, KEY_FIRST_NAME, "Erik");        	
            
            Node android = jugMembers.createNode();
            android.setProperty(KEY_TITLE, "Android");
            android.setProperty("numAttendees", 50);
            index.index(android, KEY_TITLE, "Android");
            Node augmentedReality = jugMembers.createNode();
            augmentedReality.setProperty(KEY_TITLE, "Augmented Reality");
            augmentedReality.setProperty("numAttendees", 40);
            index.index(augmentedReality, KEY_TITLE, "Augmented Reality");
            Node nosql = jugMembers.createNode();
            nosql.setProperty(KEY_TITLE, "NoSQL");	
            nosql.setProperty("numAttendees", 20);
            index.index(nosql, KEY_TITLE, "NoSQL");
            Node jee6 = jugMembers.createNode();
            jee6.setProperty(KEY_TITLE, "JEE 6");
            jee6.setProperty("numAttendees", 70);
            index.index(jee6, KEY_TITLE, "JEE 6");
            Node wave = jugMembers.createNode();
            wave.setProperty(KEY_TITLE, "Google Wave");
            wave.setProperty("numAttendees", 35);
            index.index(wave, KEY_TITLE, "Google Wave");
            
            johannes.createRelationshipTo(android, MyRelationshipTypes.ATTENDED);
            johannes.createRelationshipTo(augmentedReality, MyRelationshipTypes.ATTENDED);
            johannes.createRelationshipTo(jee6, MyRelationshipTypes.ATTENDED);
            johannes.createRelationshipTo(wave, MyRelationshipTypes.ATTENDED);
            
            erik.createRelationshipTo(android, MyRelationshipTypes.ATTENDED);
            erik.createRelationshipTo(jee6, MyRelationshipTypes.ATTENDED);
            erik.createRelationshipTo(nosql, MyRelationshipTypes.ATTENDED);
            
            tx.success();
            
            // print johannes's relationships
            for(Relationship relationship : johannes.getRelationships()) {
            	System.out.println(johannes.getProperty(KEY_FIRST_NAME) + " " + relationship.getType().toString() + " " + relationship.getEndNode().getProperty(KEY_TITLE));
            }
            // print erik's relationships
            for(Relationship relationship : erik.getRelationships()) {
            	System.out.println(erik.getProperty(KEY_FIRST_NAME) + " " + relationship.getType().toString() + " " + relationship.getEndNode().getProperty(KEY_TITLE));
            }
         
            Node erikFromDb = index.getSingleNode(KEY_FIRST_NAME, "Erik");
            System.out.println("Found by first name 'Erik'");
            System.out.println(erikFromDb.getProperty(KEY_FIRST_NAME));
            
            IndexHits<Node> eventsStartingwithA = index.getNodes(KEY_TITLE, "A*");
            System.out.println("Found by query for titles starting with 'A'");
            for(Node node : eventsStartingwithA) {
            	System.out.println(node.getProperty(KEY_TITLE));
            }
        } finally {
            tx.finish();
            jugMembers.shutdown();
        }
	}

}
