package vonderheid.erik.nosql.model;

public class Event {

	private String title;
	
	private int numAttendees;
	
	public Event(String title, int numAttendees) {
		this.title = title;
		this.numAttendees = numAttendees;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getNumAttendees() {
		return numAttendees;
	}
	public void setNumAttendees(int numAttendees) {
		this.numAttendees = numAttendees;
	}
	
}
