package vonderheid.erik.nosql.model;

public class ExampleData {

	public static JugMember erik = new JugMember("Erik", "Vonderheid", 
			new Event("Android", 50), 
			new Event("NoSQL", 20),
			new Event("JEE 6", 70));
}
