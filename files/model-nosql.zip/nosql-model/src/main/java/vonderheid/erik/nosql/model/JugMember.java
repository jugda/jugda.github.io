package vonderheid.erik.nosql.model;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import javax.persistence.Id;

@javax.persistence.Entity
public class JugMember {
	
	@Id
	private long id;
	
	private String firstName;
	private String name;
	private Collection<Event> visitedEvents;
	
	public JugMember(String firstName, String name, List<Event> events) {
		super();
		this.firstName = firstName;
		this.name = name;
		this.visitedEvents = events;
	}
	
	public JugMember(String firstName, String name, Event... events) {
		this(firstName, name, Arrays.asList(events));
	}
	
	public long getId() {
		return id;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Collection<Event> getVisitedEvents() {
		return visitedEvents;
	}

	public void setVisitedEvents(Collection<Event> visitedEvents) {
		this.visitedEvents = visitedEvents;
	}

	@Override
	public String toString() {		
		return "JugMember [firstName=" + firstName + ", name=" + name
				+ ", interestedIn=" + Arrays.toString(visitedEvents.toArray(new String[visitedEvents.size()])) + "]";
	}
	
}
