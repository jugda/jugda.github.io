package test.de.hirnsport.hc12.crossword;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import de.hirnsport.hc12.crossword.Field;
import de.hirnsport.hc12.crossword.Field.DirectionEnum;

public class FieldTest {

	private Field field = new Field();
	
	@Before
	public void setUp() throws Exception {
		field = new Field();
		field.reset();
	}

	@Test
	public void testPrintToString() {
		String expected = "________\n________\n________\n________\n________\n________\n________\n________\n";
		String output = field.printToString();
		
		Assert.assertEquals("", expected, output);
	}

	@Test
	public void testPutWord() {
		String expected = "________\n_hallo__\n__h_____\n__a_____\n__l_____\n__l_____\n__o_____\n________\n";
		
		field.putWord("hallo", 1, 1, DirectionEnum.horizontal);
		field.putWord("hallo", 2, 2, DirectionEnum.vertikal);
		
		String output = field.printToString();
		
		Assert.assertEquals("", expected, output);
	}

	@Test
	public void testReset() {
		String expected = "________\n________\n________\n________\n________\n________\n________\n________\n";
		
		field.putWord("hallo", 1, 1, DirectionEnum.horizontal);
		field.putWord("hallo", 1, 1, DirectionEnum.vertikal);
		
		String output = field.printToString();
		Assert.assertFalse( expected.equals(output));
		field.reset();
		output = field.printToString();
		Assert.assertEquals("", expected, output);
	}
	
	@Test
	public void testPutWordWithViolation() {
		String expected = "______HA\n_hallo__\n__h_____\n__a_____\n__l_____\n__l_____\n__o_____\n________\n";
		
		int violation = 0;
		
		violation += field.putWord("hallo", 1, 1, DirectionEnum.horizontal);
		Assert.assertEquals(0, violation);
		violation += field.putWord("hallo", 2, 2, DirectionEnum.vertikal);
		Assert.assertEquals(0, violation);
		violation += field.putWord("HALLO", 6, 0, DirectionEnum.horizontal);
		
		String output = field.printToString();
		
		Assert.assertEquals("", expected, output);
		Assert.assertEquals(3, violation);
	}

	
}
