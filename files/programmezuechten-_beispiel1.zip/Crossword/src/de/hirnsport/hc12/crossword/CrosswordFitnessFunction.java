package de.hirnsport.hc12.crossword;

import org.jgap.FitnessFunction;
import org.jgap.IChromosome;
import de.hirnsport.hc12.crossword.Field.DirectionEnum;

public class CrosswordFitnessFunction extends FitnessFunction {


	private static final long serialVersionUID = -4404183260726631356L;
	
	private Field field;
	private float fittness;
	
	@Override
	protected double evaluate(IChromosome a_subject) {
		
		field = new Field();
		field.reset();
		
	    for (int i = 0; i < a_subject.size(); i = i + Crossword.ELEMENTS_PER_GENE) {
	      Integer wordPos = (Integer) a_subject.getGene(i).getAllele();
	      Integer xpos = (Integer) a_subject.getGene(i+1).getAllele();
	      Integer ypos = (Integer) a_subject.getGene(i+2).getAllele();
	      Integer direction = (Integer) a_subject.getGene(i+3).getAllele();
	      DirectionEnum d = DirectionEnum.values()[direction-1];

	      String word = Crossword.WORDS[wordPos];
	      field.putWord( word, xpos, ypos, d);
	    }
	    
	    int violations = field.getViolations()+1;
		int letters = field.getLetters()+1;
		int mehrfach = field.getMehrfach()+1;
		int wordCount = field.getWordCount()+1;

		fittness =  ((letters*wordCount*mehrfach ) / (violations*violations)) ;
	    
		return (fittness);
	}

	public Field getField() {
		return field;
	}

	public void setField(Field field) {
		this.field = field;
	}

	public float getFittness() {
		return fittness;
	}

}

