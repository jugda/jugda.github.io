package de.hirnsport.hc12.crossword;

import java.text.NumberFormat;
import java.util.Locale;

import org.jgap.Chromosome;
import org.jgap.Configuration;
import org.jgap.FitnessFunction;
import org.jgap.Gene;
import org.jgap.Genotype;
import org.jgap.IChromosome;
import org.jgap.impl.CrossoverOperator;
import org.jgap.impl.DefaultConfiguration;
import org.jgap.impl.IntegerGene;
import org.jgap.impl.InversionOperator;
import org.jgap.impl.MutationOperator;

import de.hirnsport.hc12.crossword.Field.DirectionEnum;

public class Crossword {
	  

	public final static String[] WORDS = {
	      "ZEIT", "APFEL", "CAMPUS", "RADIO", "HUND", "STIFT", "MAUS","BUCH", "TOR", "GELD", "BEAMER", "DORF", "OHR", "MUND", "VOGEL", "SEE", "SONNE", "FELD", "TELLER", "GABEL", "MINUTE", "SEKUNDE", "STUNDE", "BOOT","BURG", "DACH", "BUCH", "ZELT", "KABEL", "HEMD", "ROCK", "HOSE",
	      "REGEN", "HERBST", "EIS", "ERDE", "GENOM", "HAUS", "KATZE", "EULE", "AUTO", "VORTRAG", "UHR", "NASE", "IGEL", "HASE", "BERG", "VATER", "MUTTER", "KIND", "TISCH", "FISCH", "SCHIFF", "ZUG", "LICHT", "BALL", "PFERD", "STALL", "STEIN", "TUER", "MARS", "VENUS", "PLUTO", "SATURN"};

	  public static final int MAX_ALLOWED_EVOLUTIONS = 600;
	  public static final int MAX_GENES = 25;
	  public static final int ELEMENTS_PER_GENE = 4;
	  
	  public String csv;
	  NumberFormat nf = NumberFormat.getNumberInstance(Locale.GERMAN);
	  
	  public static void main(String[] args) {
		  Crossword c = new Crossword();
		  try {
			c.ga();
		} catch (Exception e) {
			e.printStackTrace();
		}
	  }
	  
	  
	  public void ga() throws Exception
	  {
		  Configuration conf = new DefaultConfiguration();	    

		    // Definieren der Genstruktur:
		    // ------------------------------------------------------------
		    
		    Gene[] sampleGenes = new Gene[ MAX_GENES * ELEMENTS_PER_GENE ];
		    for (int i = 0; i <  MAX_GENES * ELEMENTS_PER_GENE; i = i +ELEMENTS_PER_GENE) {
		      sampleGenes[i]   = new IntegerGene(conf, 0, WORDS.length-1 );
		      sampleGenes[i+1] = new IntegerGene(conf, 0, Field.MAX_WIDTH-1 );
		      sampleGenes[i+2] = new IntegerGene(conf, 0, Field.MAX_HEIGHT-1 );
		      sampleGenes[i+3] = new IntegerGene(conf, 1, DirectionEnum.values().length );
		    }
		    IChromosome sampleChromosome = new Chromosome(conf, sampleGenes);
		    conf.setSampleChromosome(sampleChromosome);

		    // Setzten der Fitness-Funktion
		    // ------------------------------------------------------------
		    FitnessFunction myFunc = new CrosswordFitnessFunction( );
		    conf.setFitnessFunction(myFunc);		    
		    
		    // Konfigurationen setzten: Genertischen Operationen
		    // ------------------------------------------------------------
		    conf.getGeneticOperators().clear();
		    MutationOperator mutOp = new MutationOperator(conf);
		    mutOp.setMutationRate( 50 );
		    conf.addGeneticOperator(mutOp);
		    conf.addGeneticOperator(new CrossoverOperator(conf, 4));
		    conf.setPopulationSize(600);
		    conf.setPreservFittestIndividual(false);
		    
		    // Erzeugen einer ersten Generation
		    // ------------------------------------------------------------
		    Genotype population;
		    population = Genotype.randomInitialGenotype(conf);

		    // Evolution starten
		    // ---------------------------------------------------------------
		    CrosswordFitnessFunction fitnessFunction = new CrosswordFitnessFunction();
		    
		    for (int i = 0; i < MAX_ALLOWED_EVOLUTIONS; i++) {
		      population.evolve();
		      
		      // Beste L�sung der aktuellen Generation anzeigen
		      IChromosome bestSolutionSoFar = population.getFittestChromosome();
		      fitnessFunction.evaluate( bestSolutionSoFar );
		      Field field = fitnessFunction.getField();
		     
			  System.out.println( field.printToString() );
			  System.out.println( "Verletzungen:"+(field.getViolations())+" Worte:"+field.getWordCount()+"/"+MAX_GENES );
			  System.out.println( "Buchstaben:"+(field.getLetters())+" Mehrfach:"+field.getMehrfach() );
			  System.out.println( "Generation:"+i+ " Fitness:"+fitnessFunction.getFittness() );
			  
		    }

		    // Bestes Ergebnis anzeigen
		    // ---------------------------------------------------------------		    
		    IChromosome bestSolutionSoFar = population.getFittestChromosome();
		    System.out.println("The best solution has a fitness value of " +
		                       bestSolutionSoFar.getFitnessValue());

		    fitnessFunction.evaluate( bestSolutionSoFar );
		    String i = printChromosomeToString( bestSolutionSoFar );
		    System.out.println( i );
		    System.out.println( fitnessFunction.getField().printToString() );
		
	  }
	  
	  public static String printChromosomeToString( IChromosome chromosome )
	  {
		  StringBuffer sb = new StringBuffer();
		  for (int i = 0; i < chromosome.size(); i = i + ELEMENTS_PER_GENE) {
		      Integer wordPos = (Integer) chromosome.getGene(i).getAllele();
		      Integer xpos = (Integer) chromosome.getGene(i+1).getAllele();
		      Integer ypos = (Integer) chromosome.getGene(i+2).getAllele();
		      Integer direction = (Integer) chromosome.getGene(i+3).getAllele();
		      DirectionEnum d = DirectionEnum.horizontal;
		      sb.append("\nGen:"+(i+1) / ELEMENTS_PER_GENE);
		      String word = Crossword.WORDS[wordPos];
		      sb.append(" Wort:"+word);
		      String dir = DirectionEnum.values()[direction-1].name();
		      sb.append( " x:"+xpos+" y:"+ypos);
		      sb.append(" "+dir);
		  }
		  return sb.toString();
	  }
	  
}
