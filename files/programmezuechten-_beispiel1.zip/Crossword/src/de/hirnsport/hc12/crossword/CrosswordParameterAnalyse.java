package de.hirnsport.hc12.crossword;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.jgap.Chromosome;
import org.jgap.Configuration;
import org.jgap.FitnessFunction;
import org.jgap.Gene;
import org.jgap.Genotype;
import org.jgap.IChromosome;
import org.jgap.data.DataTreeBuilder;
import org.jgap.data.IDataCreators;
import org.jgap.impl.CrossoverOperator;
import org.jgap.impl.DefaultConfiguration;
import org.jgap.impl.IntegerGene;
import org.jgap.impl.MutationOperator;
import org.jgap.impl.TwoWayMutationOperator;
import org.jgap.xml.XMLDocumentBuilder;
import org.jgap.xml.XMLManager;
import org.w3c.dom.Document;

import de.hirnsport.hc12.crossword.Field.DirectionEnum;

public class CrosswordParameterAnalyse {
	  

	public final static String[] WORDS = {
	      "ZEIT", "APFEL", "CAMPUS", "RADIO", "HUND", "STIFT", "MAUS","BUCH", "TOR", "GELD", "BEAMER", "DORF", "OHR", "MUND", "VOGEL", "SEE", "SONNE", "FELD", "TELLER", "GABEL", "MINUTE", "SEKUNDE", "STUNDE", "BOOT","BURG", "DACH", "BUCH", "ZELT", "KABEL", 
	      "REGEN", "HERBST", "EIS", "ERDE", "GENOM", "HAUS", "KATZE", "EULE", "AUTO", "VORTRAG", "UHR", "NASE", "IGEL", "HASE", "BERG", "VATER", "MUTTER", "KIND", "TISCH", "FISCH", "SCHIFF", "ZUG", "LICHT", "BALL", "PFERD", "STALL", "STEIN", "TUER"};

	  public static final int MAX_ALLOWED_EVOLUTIONS = 500;
	  public static final int MAX_GENES = 20;
	  public static final int ELEMENTS_PER_GENE = 4;
	  
	  public static final int DURCHLAUFE = 12;
	  public float fitness = 0.0f; 
	  
	  
	  public static void main(String[] args) {
	  
		  //analyseMutationRecombination();
		  //analyseGenerationPopsize();
		  //analyseMutation();
		  analyseRekombination();
	  }
	  
	  public static void analyseMutationRecombination() {
		  Future[] futures = new Future[DURCHLAUFE];
		  String line = "";
		  float fitness = 0.0f;
		  NumberFormat nf = NumberFormat.getNumberInstance(Locale.GERMAN);
		  ExecutorService es = Executors.newFixedThreadPool(32);
		  CrosswordParameterAnalyse c = new CrosswordParameterAnalyse();
		  try {
			  int mutationsRate = 2;
			  int xoverRate = 2;
			  for (mutationsRate = 40; mutationsRate < 60; mutationsRate = mutationsRate +4)
			  {
				  line = "";
				  for (xoverRate = 2; xoverRate < 100; xoverRate = xoverRate+5)
				  {
					  //line = line + ";"+xoverRate;
					  fitness = 0.0f;
					  
					  for (int i = 0; i < DURCHLAUFE; i++)
					  {
						  CrosswordParameterAnalyse c1 = new CrosswordParameterAnalyse();
							futures[i] = es.submit(new MyThread( c1, mutationsRate, xoverRate, MAX_ALLOWED_EVOLUTIONS ,120  ) );
					  }
					  for (int i = 0; i < DURCHLAUFE; i++)
					  {
					    Future f = (Future) futures[i];
						fitness = fitness + ((CrosswordParameterAnalyse)f.get()).fitness;
						
					  }
					  fitness = fitness / DURCHLAUFE;
					  line = line + ";"+nf.format(fitness);
				  }
				  System.out.println(line );
			  }

		} catch (Exception e) {
			e.printStackTrace();
		}
	  }
	  
	  public static void analyseGenerationPopsize() {
		  Future[] futures = new Future[DURCHLAUFE];
		  String line = "";
		  float fitness = 0.0f;
		  NumberFormat nf = NumberFormat.getNumberInstance(Locale.GERMAN);
		  ExecutorService es = Executors.newFixedThreadPool(32);
		  CrosswordParameterAnalyse c = new CrosswordParameterAnalyse();
		  try {
			  int popsize = 10;
			  int maxgenerations = 100;
			  for (popsize = 40; popsize < 400; popsize = popsize + 20)
			  {
				  line = "";
				  for (maxgenerations = 100; maxgenerations < 5000; maxgenerations=maxgenerations+100)
				  {
					  //line = line + ";"+xoverRate;
					  fitness = 0.0f;
					  
					  for (int i = 0; i < DURCHLAUFE; i++)
					  {
						  CrosswordParameterAnalyse c1 = new CrosswordParameterAnalyse();
							futures[i] = es.submit(new MyThread( c1, 40 , 3, maxgenerations ,popsize  ) );
					  }
					  for (int i = 0; i < DURCHLAUFE; i++)
					  {
					    Future f = (Future) futures[i];
						fitness = fitness + ((CrosswordParameterAnalyse)f.get()).fitness;
						
					  }
					  fitness = fitness / DURCHLAUFE;
					  line = line + ";"+nf.format(fitness);
				  }
				  System.out.println(line );
			  }

		} catch (Exception e) {
			e.printStackTrace();
		}
	  }
	  
	  public static void analyseMutation() {
		  Future[] futures = new Future[DURCHLAUFE];
		  String line = "";
		  float fitness = 0.0f;
		  NumberFormat nf = NumberFormat.getNumberInstance(Locale.GERMAN);
		  ExecutorService es = Executors.newFixedThreadPool(32);
		  CrosswordParameterAnalyse c = new CrosswordParameterAnalyse();
		  try {
			  int mutationsRate = 2;
			  int xoverRate = 2;
			  for (mutationsRate = 2; mutationsRate < 300; mutationsRate = mutationsRate +4)
			  {
				  
				  fitness = 0.0f;
				  float fitnessMin = Float.MAX_VALUE;
				  float fitnessMax = 0.0f;
				  
				  for (int i = 0; i < DURCHLAUFE; i++)
				  {
					  CrosswordParameterAnalyse c1 = new CrosswordParameterAnalyse();
					  futures[i] = es.submit(new MyThread( c1, mutationsRate, xoverRate, MAX_ALLOWED_EVOLUTIONS ,100  ) );
				  }
				  for (int i = 0; i < DURCHLAUFE; i++)
				  {
					  Future f = (Future) futures[i];
					  float aktFitness = ((CrosswordParameterAnalyse)f.get()).fitness;
					  fitness = fitness + aktFitness;
					  if ( aktFitness > fitnessMax )
						  fitnessMax = aktFitness;
					  if ( aktFitness < fitnessMin )
						  fitnessMin = aktFitness;
				  }
				  fitness = fitness / DURCHLAUFE;
				  line = mutationsRate + ";"+nf.format(fitnessMin)+";"+nf.format(fitness)+";"+nf.format(fitnessMax);
				  System.out.println(line );
			  }

		} catch (Exception e) {
			e.printStackTrace();
		}
	  }	  
	  
	  public static void analyseRekombination() {
		  Future[] futures = new Future[DURCHLAUFE];
		  String line = "";
		  float fitness = 0.0f;
		  NumberFormat nf = NumberFormat.getNumberInstance(Locale.GERMAN);
		  ExecutorService es = Executors.newFixedThreadPool(32);
		  CrosswordParameterAnalyse c = new CrosswordParameterAnalyse();
		  try {
			  int mutationsRate = 10;
			  int xoverRate = 2;
			  for (xoverRate = 2; xoverRate < 100; xoverRate = xoverRate +2)
			  {
				  
				  fitness = 0.0f;
				  float fitnessMin = Float.MAX_VALUE;
				  float fitnessMax = 0.0f;
				  
				  for (int i = 0; i < DURCHLAUFE; i++)
				  {
					  CrosswordParameterAnalyse c1 = new CrosswordParameterAnalyse();
					  futures[i] = es.submit(new MyThread( c1, mutationsRate, xoverRate, MAX_ALLOWED_EVOLUTIONS ,100  ) );
				  }
				  for (int i = 0; i < DURCHLAUFE; i++)
				  {
					  Future f = (Future) futures[i];
					  float aktFitness = ((CrosswordParameterAnalyse)f.get()).fitness;
					  fitness = fitness + aktFitness;
					  if ( aktFitness > fitnessMax )
						  fitnessMax = aktFitness;
					  if ( aktFitness < fitnessMin )
						  fitnessMin = aktFitness;
				  }
				  fitness = fitness / DURCHLAUFE;
				  line = xoverRate + ";"+nf.format(fitnessMin)+";"+nf.format(fitness)+";"+nf.format(fitnessMax);
				  System.out.println(line );
			  }

		} catch (Exception e) {
			e.printStackTrace();
		}
	  }	  	  
	  
	  public float ga(int mutation, int xover, int maxGenerations, int populationSize ) throws Exception
	  {
		  Configuration conf = new DefaultConfiguration();
		  conf.reset();
		    conf.setPreservFittestIndividual(true);
		    
		    conf.getGeneticOperators().clear();
//		    IUniversalRateCalculator mutCalc = new CoinsMutationRateCalc();
//		    TwoWayMutationOperator mutOp = new TwoWayMutationOperator(conf, 7);
		    MutationOperator mutOp = new MutationOperator(conf);
		    mutOp.setMutationRate( mutation );
		    conf.addGeneticOperator(mutOp);
		    conf.addGeneticOperator(new CrossoverOperator(conf, xover));
		    
		    // Set the fitness function we want to use. We construct it with
		    // the target volume passed in to this method.
		    // ---------------------------------------------------------
		    FitnessFunction myFunc =
		        new CrosswordFitnessFunction( );
		    conf.setFitnessFunction(myFunc);
		    // Now we need to tell the Configuration object how we want our
		    // Chromosomes to be setup. We do that by actually creating a
		    // sample Chromosome and then setting it on the Configuration
		    // object. As mentioned earlier, we want our Chromosomes to each
		    // have as many genes as there are different items available. We want the
		    // values (alleles) of those genes to be integers, which represent
		    // how many items of that type we have. We therefore use the
		    // IntegerGene class to represent each of the genes. That class
		    // also lets us specify a lower and upper bound, which we set
		    // to senseful values (i.e. maximum possible) for each item type.
		    // --------------------------------------------------------------
		    Gene[] sampleGenes = new Gene[ MAX_GENES * ELEMENTS_PER_GENE ];
		    for (int i = 0; i <  MAX_GENES * ELEMENTS_PER_GENE; i = i +ELEMENTS_PER_GENE) {
		      sampleGenes[i]   = new IntegerGene(conf, 0, WORDS.length-1 );
		      sampleGenes[i+1] = new IntegerGene(conf, 0, Field.MAX_WIDTH-1 );
		      sampleGenes[i+2] = new IntegerGene(conf, 0, Field.MAX_HEIGHT-1 );
		      sampleGenes[i+3] = new IntegerGene(conf, 1, DirectionEnum.values().length );
		    }
		    IChromosome sampleChromosome = new Chromosome(conf, sampleGenes);
		    conf.setSampleChromosome(sampleChromosome);
		    // Finally, we need to tell the Configuration object how many
		    // Chromosomes we want in our population. The more Chromosomes,
		    // the larger number of potential solutions (which is good for
		    // finding the answer), but the longer it will take to evolve
		    // the population (which could be seen as bad).
		    // ------------------------------------------------------------
		    conf.setPopulationSize(populationSize);
		    
		    // Create random initial population of Chromosomes.
		    // Here we try to read in a previous run via XMLManager.readFile(..)
		    // for demonstration purpose!
		    // -----------------------------------------------------------------
		    Genotype population;
		   
		    population = Genotype.randomInitialGenotype(conf);
		    // Evolve the population. Since we don't know what the best answer
		    // is going to be, we just evolve the max number of times.
		    // ---------------------------------------------------------------
		    
		    CrosswordFitnessFunction f = new CrosswordFitnessFunction();
		    for (int i = 0; i < maxGenerations; i++) {
		      population.evolve();
		      IChromosome bestSolutionSoFar = population.getFittestChromosome();
		      f.evaluate( bestSolutionSoFar );
//		      if ( i % 1000 == 0)
//		    	  System.out.println( "Gen: "+i );
		    }
		    // Save progress to file. A new run of this example will then be able to
		    // resume where it stopped before!
		    // ---------------------------------------------------------------------

		    
		    IChromosome bestSolutionSoFar = population.getFittestChromosome();
		    //System.out.println("Bestfitness " +  bestSolutionSoFar.getFitnessValue());
		    float afitness = (float)bestSolutionSoFar.getFitnessValue();
		    this.fitness = afitness;
		    return afitness;
	  }
	  
	  public static String printChromosomeToString( IChromosome chromosome )
	  {
		  StringBuffer sb = new StringBuffer();
		  for (int i = 0; i < chromosome.size(); i = i + ELEMENTS_PER_GENE) {
			      Integer wordPos = (Integer) chromosome.getGene(i).getAllele();
			      Integer xpos = (Integer) chromosome.getGene(i+1).getAllele();
			      Integer ypos = (Integer) chromosome.getGene(i+2).getAllele();
			      Integer direction = (Integer) chromosome.getGene(i+3).getAllele();
			      DirectionEnum d = DirectionEnum.horizontal;
			      sb.append("\nGennr:"+i / ELEMENTS_PER_GENE);
			      sb.append("\n");
			      String word = CrosswordParameterAnalyse.WORDS[wordPos];
			      sb.append(" Word:"+word);
			      sb.append("\n");
			      String dir = "";
			      if ( direction == 1 )
			      {
			    	  dir = "horizontal";
//			    	  if ((ypos + word.length()) > 7 )
//			    		  ypos = (ypos + word.length()) % 8;
			    	  
			      } else if ( direction == 2 )
			      {
			    	  dir = "vertical";
//			    	  if  ((xpos + word.length()) > 7)
//			    	  	xpos = (xpos + word.length()) % 8;
			      }

			      sb.append( " x:"+xpos+" y:"+ypos);
			      sb.append(" "+dir);

		  }
		  return sb.toString();
	  }
	  
}
class MyThread implements Callable {
	private CrosswordParameterAnalyse i;
	private int mutationRate=2;
	private int xoverRate=2;
	private int maxGenerations;
	private int populationSize;
	
	public float fitness;
	  MyThread(CrosswordParameterAnalyse ii, int m, int xover, int maxGenerations, int populationSize) {
	  this.i = ii;
	  this.mutationRate = m;
	  this.xoverRate = xover;
	  this.maxGenerations = maxGenerations;
	  this.populationSize = populationSize;
	  }

	  
	  public CrosswordParameterAnalyse get()
	  {
		  return i;
	  }

	@Override
	public CrosswordParameterAnalyse call() throws Exception {
//		System.out.println( ""+i );
		fitness=i.ga(mutationRate, xoverRate,maxGenerations, populationSize);
		return i;
	}
	}

