package de.kompf.jugda.testing.cdi;

import static org.junit.Assert.*;

import javax.inject.Inject;

import org.jboss.arquillian.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ArchivePaths;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.Test;
import org.junit.runner.RunWith;

import de.kompf.jugda.testing.basic.Calculator;
import de.kompf.jugda.testing.basic.CalculatorImpl;

@RunWith(Arquillian.class)
public class CalculatorServiceTest {

	@Inject
	private CalculatorService calcService;

	@Deployment
	public static JavaArchive createTestArchive() {
		return ShrinkWrap.create(JavaArchive.class, "test.jar")
				.addClasses(Calculator.class, CalculatorImpl.class,
						CalculatorService.class).addManifestResource(
						EmptyAsset.INSTANCE, ArchivePaths.create("beans.xml"));
	}

	@Test
	public void testBinomialCoefficient() {
		assertEquals(1, calcService.binomialCoefficient(0, 0));
		assertEquals(1, calcService.binomialCoefficient(1, 1));
		assertEquals(1, calcService.binomialCoefficient(1, 0));
		assertEquals(2, calcService.binomialCoefficient(2, 1));
		assertEquals(35, calcService.binomialCoefficient(7, 3));
	}
}
