package de.kompf.jugda.testing.cdi;

import javax.inject.Inject;

import de.kompf.jugda.testing.basic.Calculator;

public class CalculatorService {

	@Inject
	Calculator calc;
	
	public long binomialCoefficient(int n, int k) {
		return calc.nfac(n) / calc.nfac(n-k) / calc.nfac(k);
	}
}
