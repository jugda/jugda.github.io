package vonderheid.erik.nosql.mongodb;

import java.net.UnknownHostException;
import java.util.List;

import vonderheid.erik.nosql.model.Event;
import vonderheid.erik.nosql.model.JugMember;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;


public class Main {

	/**
	 * @param args
	 * @throws MongoException 
	 * @throws UnknownHostException 
	 */
	public static void main(String[] args) throws UnknownHostException, MongoException {
		Mongo m = new Mongo( "localhost" , 27017 );

		// 'mydb' will be created if it doesn't exist
		DB db = m.getDB("mydb");
		
		DBCollection jugMembers = db.getCollection("jugMembers");
		// clear collection
		jugMembers.drop();
		
		// create first member
		JugMember johannes = new JugMember("Johannes", "Leebmann", 
				new Event("Android", 50), 
				new Event("Augmented Reality", 40),
				new Event("JEE 6", 70),
				new Event("Google Wave", 35));
		jugMembers.insert(new JugMemberDbObject(johannes));
		
		// create second member
		JugMember erik = new JugMember("Erik", "Vonderheid", 
				new Event("Android", 50), 
				new Event("NoSQL", 20),
				new Event("JEE 6", 70));
		JugMemberDbObject erikDb = new JugMemberDbObject(erik);
		jugMembers.insert(erikDb);
		
		// find first member
		DBObject foundMember = jugMembers.findOne();
		System.out.println("First entry:");
		System.out.println(foundMember);
		
		// query for all members who visited the Android talk
		DBObject query = new BasicDBObject();
		query.put("visitedEvents.title", "Android");
		DBCursor cursor = jugMembers.find(query);
		System.out.println("All Android attendees:");
		while(cursor.hasNext()) {
			System.out.println(cursor.next());
		}
		
		// query for all members who visited the 'Augmented Reality' talk
		query = new BasicDBObject();
		query.put("visitedEvents.title", "Augmented Reality");
		cursor = jugMembers.find(query);
		System.out.println("All 'Augmented Reality' attendees:");
		while(cursor.hasNext()) {
			System.out.println(cursor.next());
		}
		
		// create index on the title of the visited events
		// '1' means ascending
		DBObject javaIndex = new BasicDBObject("visitedEvents.title", 1);
		jugMembers.createIndex(javaIndex);
		List<DBObject> indexInfos = jugMembers.getIndexInfo();
		System.out.println("Index informations:");
		for(DBObject indexInfo : indexInfos) {
			System.out.println(indexInfo);
		}
		
		jugMembers.remove(erikDb);
		
		// query for all members who visited the Android talk
		query = new BasicDBObject();
		query.put("visitedEvents.title", "Android");
		cursor = jugMembers.find(query);
		System.out.println("Only one Android attendee left:");
		while(cursor.hasNext()) {
			System.out.println(cursor.next());
		}
	}

}
