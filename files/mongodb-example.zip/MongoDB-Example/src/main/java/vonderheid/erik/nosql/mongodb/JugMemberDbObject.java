package vonderheid.erik.nosql.mongodb;

import vonderheid.erik.nosql.model.Event;
import vonderheid.erik.nosql.model.JugMember;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class JugMemberDbObject extends BasicDBObject {

	/**
	 * Generated UID
	 */
	private static final long serialVersionUID = -1626604698631739360L;

	public JugMemberDbObject(JugMember member) {
		put("firstName", member.getFirstName());
		put("name", member.getName());
		BasicDBList visitedEvents = new BasicDBList();
		for(Event event : member.getVisitedEvents()) {
			DBObject dbEvent = new BasicDBObject();
			dbEvent.put("title", event.getTitle());
			dbEvent.put("numAttendees", event.getNumAttendees());
			visitedEvents.add(dbEvent);
		}
		put("visitedEvents", visitedEvents);
	}
}
